import { NextResponse } from 'next/server'

const OWNER = 'a23521745-hub'
const REPOSITORY = 'OTA-Deneyi'

export async function GET() {
  const headers: HeadersInit = {
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
  }

  if (process.env.GITHUB_TOKEN) {
    headers.Authorization = `Bearer ${process.env.GITHUB_TOKEN}`
  }

  try {
    const response = await fetch(
      `https://api.github.com/repos/${OWNER}/${REPOSITORY}/releases/latest`,
      { headers, next: { revalidate: 60 } },
    )

    if (!response.ok) {
      return NextResponse.json(
        { error: 'GitHub Releases verisi alınamadı.', status: response.status },
        { status: response.status },
      )
    }

    const release = await response.json()
    const apk = release.assets?.find((asset: { name?: string }) =>
      asset.name?.toLowerCase().endsWith('.apk'),
    )
    const versionCodeMatch = release.body?.match(/versionCode\s*[:=]\s*(\d+)/i)
    const tagVersion = release.tag_name?.replace(/^v/, '') ?? '0.0.0'

    return NextResponse.json({
      repository: `${OWNER}/${REPOSITORY}`,
      versionName: tagVersion,
      versionCode: Number(versionCodeMatch?.[1] ?? 0),
      releaseName: release.name ?? release.tag_name,
      publishedAt: release.published_at,
      releaseUrl: release.html_url,
      apk: apk
        ? { name: apk.name, size: apk.size, downloadUrl: apk.browser_download_url }
        : null,
    })
  } catch {
    return NextResponse.json({ error: 'GitHub bağlantısı kurulamadı.' }, { status: 503 })
  }
}

export const dynamic = 'force-dynamic'

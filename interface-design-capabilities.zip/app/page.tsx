import { OtaDashboard } from '@/components/ota-dashboard'

export default function Page() {
  return <OtaDashboard />
}

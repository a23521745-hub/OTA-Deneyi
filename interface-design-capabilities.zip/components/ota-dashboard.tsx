'use client'

import { useCallback, useEffect, useState } from 'react'
import {
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Download,
  ExternalLink,
  GitBranch,
  KeyRound,
  Loader2,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  TriangleAlert,
} from 'lucide-react'

const CURRENT_VERSION = { name: '1.0.0', code: 1 }

type Release = {
  repository: string
  versionName: string
  versionCode: number
  releaseName: string
  publishedAt: string
  releaseUrl: string
  apk: { name: string; size: number; downloadUrl: string } | null
}

function formatDate(value?: string) {
  if (!value) return 'Henüz kontrol edilmedi'
  return new Intl.DateTimeFormat('tr-TR', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(value))
}

function formatSize(bytes?: number) {
  if (!bytes) return '—'
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

export function OtaDashboard() {
  const [release, setRelease] = useState<Release | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [checkedAt, setCheckedAt] = useState<Date | null>(null)
  const [confirming, setConfirming] = useState(false)

  const checkRelease = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const response = await fetch('/api/releases', { cache: 'no-store' })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Release kontrolü başarısız.')
      setRelease(data)
      setCheckedAt(new Date())
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Beklenmeyen bir hata oluştu.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { checkRelease() }, [checkRelease])

  const hasUpdate = Boolean(release && release.versionCode > CURRENT_VERSION.code)
  const isCurrent = Boolean(release && release.versionCode <= CURRENT_VERSION.code)

  return (
    <main className="min-h-screen bg-background text-foreground">
      <div className="flex min-h-screen flex-col lg:flex-row">
        <aside className="flex w-full flex-col justify-between bg-sidebar px-6 py-6 text-sidebar-foreground lg:min-h-screen lg:w-72 lg:px-7 lg:py-8">
          <div className="flex flex-col gap-10">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground"><ShieldCheck className="size-5" /></div>
              <div><p className="text-sm font-semibold tracking-tight">OTA Deneyi</p><p className="text-xs text-sidebar-foreground/60">Release merkezi</p></div>
            </div>
            <nav aria-label="Ana menü" className="flex flex-row gap-2 lg:flex-col">
              <button className="flex items-center gap-3 rounded-lg bg-sidebar-accent px-3 py-2.5 text-sm font-medium"><Smartphone className="size-4" /> Güncelleme</button>
              <a className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-sidebar-foreground/60 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground" href="https://github.com/a23521745-hub/OTA-Deneyi" target="_blank" rel="noreferrer"><GitBranch className="size-4" /> GitHub Releases <ExternalLink className="ml-auto size-3" /></a>
            </nav>
          </div>
          <div className="hidden flex-col gap-3 border-t border-sidebar-border pt-5 lg:flex"><p className="text-xs font-medium text-sidebar-foreground/50">Güvenlik durumu</p><div className="flex items-center gap-2 text-sm"><span className="size-2 rounded-full bg-emerald-400" /> İmzalı APK akışı aktif</div></div>
        </aside>

        <section className="flex-1 bg-muted/30">
          <header className="flex flex-col gap-4 border-b border-border bg-background px-6 py-6 md:flex-row md:items-center md:justify-between md:px-10 lg:px-12">
            <div><p className="text-sm text-muted-foreground">Uygulama yönetimi / OTA</p><h1 className="mt-1 text-2xl font-semibold tracking-tight text-balance">Güncelleme merkezi</h1></div>
            <button onClick={checkRelease} disabled={loading} className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60">{loading ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />} Şimdi denetle</button>
          </header>

          <div className="mx-auto flex max-w-6xl flex-col gap-6 p-6 md:p-10 lg:p-12">
            {error && <div role="alert" className="flex items-start gap-3 rounded-xl border border-destructive/25 bg-destructive/5 p-4 text-sm text-destructive"><TriangleAlert className="mt-0.5 size-4 shrink-0" /><div><p className="font-medium">Kontrol tamamlanamadı</p><p className="mt-1 text-destructive/80">{error}</p></div></div>}
            <div className="grid gap-4 md:grid-cols-3">
              <div className="rounded-2xl border border-border bg-card p-5"><div className="flex items-center justify-between"><p className="text-sm text-muted-foreground">Yüklü sürüm</p><Smartphone className="size-4 text-muted-foreground" /></div><p className="mt-5 text-3xl font-semibold tracking-tight">v{CURRENT_VERSION.name}</p><p className="mt-1 text-xs text-muted-foreground">versionCode {CURRENT_VERSION.code}</p></div>
              <div className="rounded-2xl border border-border bg-card p-5"><div className="flex items-center justify-between"><p className="text-sm text-muted-foreground">Son release</p><GitBranch className="size-4 text-muted-foreground" /></div><p className="mt-5 text-3xl font-semibold tracking-tight">{release ? `v${release.versionName}` : '—'}</p><p className="mt-1 text-xs text-muted-foreground">{release ? `versionCode ${release.versionCode}` : 'GitHub bekleniyor'}</p></div>
              <div className={`rounded-2xl border p-5 ${hasUpdate ? 'border-amber-300/70 bg-amber-50/60' : 'border-emerald-200 bg-emerald-50/60'}`}><div className="flex items-center justify-between"><p className="text-sm text-muted-foreground">Durum</p>{hasUpdate ? <TriangleAlert className="size-4 text-amber-600" /> : <CheckCircle2 className="size-4 text-emerald-600" />}</div><p className={`mt-5 text-xl font-semibold ${hasUpdate ? 'text-amber-800' : 'text-emerald-800'}`}>{loading ? 'Kontrol ediliyor' : hasUpdate ? 'Yeni sürüm hazır' : isCurrent ? 'Uygulama güncel' : 'Bekleniyor'}</p><p className="mt-2 text-xs text-muted-foreground">{checkedAt ? `Son kontrol: ${checkedAt.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}` : 'İlk kontrol yapılıyor'}</p></div>
            </div>

            <div className="grid gap-6 lg:grid-cols-[1.35fr_0.65fr]">
              <div className="rounded-2xl border border-border bg-card p-6 md:p-7"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Release doğrulama</p><h2 className="mt-2 text-xl font-semibold">{release?.releaseName || 'GitHub Releases bağlantısı'}</h2></div><span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-medium text-emerald-700">Canlı</span></div><div className="mt-7 flex flex-col gap-4"><div className="flex items-center justify-between border-b border-border pb-4 text-sm"><span className="text-muted-foreground">Repository</span><a className="flex items-center gap-1 font-medium hover:underline" href="https://github.com/a23521745-hub/OTA-Deneyi" target="_blank" rel="noreferrer">a23521745-hub/OTA-Deneyi <ArrowUpRight className="size-3" /></a></div><div className="flex items-center justify-between border-b border-border pb-4 text-sm"><span className="text-muted-foreground">Yayın tarihi</span><span className="font-medium">{formatDate(release?.publishedAt)}</span></div><div className="flex items-center justify-between border-b border-border pb-4 text-sm"><span className="text-muted-foreground">APK paketi</span><span className="font-medium">{release?.apk ? `${release.apk.name} · ${formatSize(release.apk.size)}` : 'APK bulunamadı'}</span></div><div className="flex items-center justify-between text-sm"><span className="text-muted-foreground">Kontrol aralığı</span><span className="flex items-center gap-1.5 font-medium"><Clock3 className="size-3.5 text-muted-foreground" /> Uygulama açılışında</span></div></div>{hasUpdate && release?.apk && <button onClick={() => setConfirming(true)} className="mt-7 flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-medium text-primary-foreground hover:opacity-90"><Download className="size-4" /> Güncellemeyi indir</button>}{isCurrent && <div className="mt-7 flex items-center gap-3 rounded-xl bg-emerald-50 p-4 text-sm text-emerald-800"><Check className="size-4" /><span>Yeni bir sürüm bulunmuyor. Uygulamanız güncel.</span></div>}</div>
              <div className="flex flex-col gap-6"><div className="rounded-2xl border border-border bg-card p-6"><div className="flex items-center gap-3"><div className="flex size-9 items-center justify-center rounded-lg bg-emerald-100 text-emerald-700"><KeyRound className="size-4" /></div><div><h2 className="font-semibold">İmza güvenliği</h2><p className="text-xs text-muted-foreground">APK doğrulama politikası</p></div></div><div className="mt-5 flex flex-col gap-3 text-sm"><div className="flex items-center gap-2"><CheckCircle2 className="size-4 text-emerald-600" /> RSA-2048 keystore</div><div className="flex items-center gap-2"><CheckCircle2 className="size-4 text-emerald-600" /> İmzalı release zorunlu</div><div className="flex items-center gap-2"><CheckCircle2 className="size-4 text-emerald-600" /> Kullanıcı onayı gerekli</div></div></div><a href={release?.releaseUrl || 'https://github.com/a23521745-hub/OTA-Deneyi/releases'} target="_blank" rel="noreferrer" className="flex items-center justify-between rounded-2xl border border-border bg-card p-5 text-sm transition-colors hover:bg-muted/50"><span><span className="block font-medium">GitHub Actions</span><span className="mt-1 block text-xs text-muted-foreground">Release pipeline&apos;ını görüntüle</span></span><ChevronRight className="size-4 text-muted-foreground" /></a></div>
            </div>
          </div>
        </section>
      </div>

      {confirming && release?.apk && <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/30 p-6"><div role="dialog" aria-modal="true" aria-labelledby="download-title" className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-2xl"><h2 id="download-title" className="text-lg font-semibold">Güncelleme indirilsin mi?</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">v{release.versionName} sürümü indirilecek. APK kurulumunu tamamlamak için Android sistem ekranında ayrıca onay vermen gerekir.</p><div className="mt-6 flex justify-end gap-3"><button onClick={() => setConfirming(false)} className="rounded-lg px-4 py-2 text-sm font-medium text-muted-foreground hover:bg-muted">Vazgeç</button><a href={release.apk.downloadUrl} target="_blank" rel="noreferrer" onClick={() => setConfirming(false)} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"><Download className="size-4" /> İndir</a></div></div></div>}
    </main>
  )
}
